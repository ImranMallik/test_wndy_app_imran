<!--begin::Page Vendors(used by this page)-->
<script src="../backend_assets/plugins/custom/datatables/datatables.bundle.js"></script>
<!--end::Page Vendors-->
<script src="templates/Whatsapp_Log/controller.js?v=<?php echo $version; ?>"></script>