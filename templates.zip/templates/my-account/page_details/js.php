<script src="templates/my-account/controller.js?v=<?php echo $version; ?>"></script>
<script>
        // Share button functionality
        // document.querySelector('.share-button').addEventListener('click', async () => {
        //     try {
        //         await navigator.share({
        //             title: 'My Referral Link',
        //             text: 'Use my referral code: RC51594546WEXF2324',
        //             url: window.location.href
        //         });
        //     } catch (err) {
        //         console.log('Share failed:', err.message);
        //         // Fallback copy to clipboard
        //         navigator.clipboard.writeText('RC51594546WEXF2324')
        //             .then(() => alert('Referral code copied to clipboard!'))
        //             .catch(err => console.error('Failed to copy:', err));
        //     }
        // });
    </script>