
<script src="templates/about-us/controller.js?v=<?php echo $version; ?>"></script>