<script src="templates/demand_post/controller.js?v=<?php echo $version; ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<!-- google API key -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDh2es6pslELdbUx-qh7DL60Rypi7epPZQ&libraries=places"></script>