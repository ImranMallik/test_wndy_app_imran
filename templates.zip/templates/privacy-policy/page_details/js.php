
<script src="templates/privacy-policy/controller.js?v=<?php echo $version; ?>"></script>