<script src="templates/direct_transfer/controller.js?v=<?php echo $version; ?>"></script>
