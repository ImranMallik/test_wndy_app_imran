
<script src="templates/shipping-returns-refund-policy/controller.js?v=<?php echo $version; ?>"></script>