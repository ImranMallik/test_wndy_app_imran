<title>
    Assigned Product List | <?php echo $system_name; ?>
</title>
