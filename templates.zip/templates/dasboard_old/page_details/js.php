<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="templates/dashboard/controller.js?v=<?php echo $version; ?>"></script>