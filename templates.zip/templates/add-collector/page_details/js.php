<!--begin::Page Vendors(used by this page)-->
<!--begin::Page Vendors(used by this page)-->
<!-- <script src="../backend_assets/plugins/custom/datatables/datatables.bundle.js"></script> -->
<script src="frontend_assets/assets/global/plugins/select2/js/select2.full.min.js?v=<?php echo $version; ?>" type="text/javascript"></script>
<!--end::Page Vendors-->
<!-- <script src="../backend_assets/ckeditor/ckeditor.js"></script> -->
<!--end::Page Vendors-->
<script src="templates/add-collector/controller.js?v=<?php echo $version; ?>"></script>