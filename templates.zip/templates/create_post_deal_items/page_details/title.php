<title>
    Deal Items | <?php echo $system_name; ?>
</title>
