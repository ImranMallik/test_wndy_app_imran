
<script src="templates/terms-conditions/controller.js?v=<?php echo $version; ?>"></script>