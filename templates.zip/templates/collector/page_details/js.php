<script src="templates/collector/controller.js?v=<?php echo $version; ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>