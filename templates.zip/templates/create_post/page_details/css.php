<style>
       .no-products-found {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 50vh;
        width: -webkit-fill-available;
        font-family: Arial, sans-serif;
        text-align: center;
        color: #ff0000;
    }

    .no-products-found h3 {
        margin: 0;
        font-size: 36px;
        font-weight: bold;
        color: #c1c1c1;
    }
</style>