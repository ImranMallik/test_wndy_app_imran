<!--begin::Page Vendors Styles(used by this page)-->
<link href="../backend_assets/plugins/custom/datatables/datatables.bundle.css?v=<?php echo $version; ?>" rel="stylesheet" type="text/css" />
<!--end::Page Vendors Styles-->