<script src="frontend_assets/assets/global/plugins/icheck/icheck.min.js" type="text/javascript"></script>
<!-- <script src="frontend_assets/assets/global/scripts/app.min.js" type="text/javascript"></script> -->
<script src="templates/buyer-profile-updation/controller.js?v=<?php echo $version; ?>"></script>