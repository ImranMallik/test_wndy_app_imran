<script src="frontend_assets/assets/global/plugins/icheck/icheck.min.js?v=<?php echo $version; ?>" type="text/javascript"></script>
<script src="templates/footer/controller.js?v=<?php echo $version; ?>"></script>
<script src="templates/footer/page_details/css.php?v=<?php echo $version; ?>"></script>

