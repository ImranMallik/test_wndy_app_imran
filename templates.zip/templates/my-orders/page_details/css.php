<!--begin::Page Vendors Styles(used by this page)-->
<style>
.status-label{
    margin-left: 10px;
    background: #69b9ff;
    font-size: 12px;
    padding: 3px 13px;
    border-radius: 5px;
    color: aliceblue;
}
.date-label{
    margin-left: 10px;
    background: #262626;
    font-size: 12px;
    padding: 3px 13px;
    border-radius: 5px;
    color: aliceblue;
}
</style>
<!--end::Page Vendors Styles-->