<?php
include("../db/db.php");
include("../../module_function/notification_details.php");
include("../../module_function/sms_gateway_api.php");
include("../../module_function/whatsapp_notification.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);


mysqli_query($con, "SET FOREIGN_KEY_CHECKS = 0");

if ($login == "No") {
    $status = "SessionDestroy";
    $status_text = "";
} else {
    $sendData = json_decode($_POST['sendData'], true);

    $baseUrl = mysqli_real_escape_string($con, $sendData['baseUrl']);
    $create_post_id = mysqli_real_escape_string($con, $sendData['create_post_id']);
    $view_id = mysqli_real_escape_string($con, $sendData['view_id']);
    $pickup_date = mysqli_real_escape_string($con, $sendData['pickup_date']);
    $pickup_time = mysqli_real_escape_string($con, $sendData['pickup_time']);

    $execute = 1;

    // Check if the product is valid
    if ($execute == 1) {
        $product_dataget = mysqli_query($con, "SELECT * FROM tbl_create_post WHERE create_post_id='$create_post_id'");
        $product_data = mysqli_fetch_row($product_dataget);
        $product_id = $product_data[1];

        if (!$product_data) {
            $status = "error";
            $status_text = "Product Details Not Found";
            $execute = 0;
        }
    }

    if ($execute == 1) {

        $dataget = mysqli_query($con, "select negotiation_amount from tbl_create_post_item_transactions where view_id='$view_id' ");
        $data = mysqli_fetch_row($dataget);
        $negotiation_amount = $data[0];

        // UPDATE in tbl_create_post_item_transactions
        mysqli_query($con, "UPDATE tbl_create_post_item_transactions SET 
            deal_status='Pickup Scheduled',
            purchased_price='" . $negotiation_amount . "',
            pickup_date='" . $pickup_date . "',
            pickup_time='" . $pickup_time . "',
            entry_timestamp='$timestamp'
            WHERE view_id='$view_id' ");

        // UPDATE in tbl_create_post_item_transactions all request will be closed 
        mysqli_query($con, "UPDATE tbl_create_post_item_transactions SET 
            deal_status='Offer Rejected',
            entry_timestamp='$timestamp'
            WHERE view_id<>'$view_id' and product_id='$product_id' and seller_id='$session_user_code' ");

        // UPDATE in tbl_product_master
        mysqli_query($con, "UPDATE tbl_create_post SET 
            product_status='Pickup Scheduled'
            WHERE create_post_id='$create_post_id' ");

        // buyer & collector will be notified that seller accept and schedule the pickup for a product
        $dataget = mysqli_query($con, "select buyer_id, assigned_collecter, seller_id from tbl_create_post_item_transactions where view_id='" . $view_id . "' ");
        $data = mysqli_fetch_row($dataget);

        $buyer_id = $data[0];
        $assigned_collecter = $data[1];
        $seller_id = $data[2];

        $productDataget = mysqli_query($con, "select 
            tbl_create_post.create_post_name,
            from tbl_create_post
            where tbl_create_post.create_post_id='" . $create_post_id . "' ");
        $productData = mysqli_fetch_assoc($productDataget);

        $product_name = $productData['create_post_name'];

        $noti_title = "Pickup Schedule From Seller";
        $noti_details = $product_name . " item pickup schedule date " . $pickup_date . " set by seller";
        $noti_url = $baseUrl . "/create_post_details/" . $create_post_id;
        $noti_to_user_id = $buyer_id;
        $noti_from_user_id = $session_user_code;
        insertNotificationDetails();

        // assigned collector not blank
        if ($assigned_collecter != "") {
            $noti_to_user_id = $assigned_collecter;
            insertNotificationDetails();
        }

        ## buyer & collector will get sms if seller has been accepted and scheduled for a pickup
        ## seller primary phone number gets
        $sellerPrimaryPhoneNumDataGet = mysqli_query($con, "SELECT ph_num, name FROM tbl_user_master WHERE user_id = '" . $seller_id . "'");
        $sellerPrimaryPhoneNumData = mysqli_fetch_row($sellerPrimaryPhoneNumDataGet);
        $sellerPrimaryPhoneNum = $sellerPrimaryPhoneNumData[0];
        $sellerName = $sellerPrimaryPhoneNumData[1];

        ## seller secondary phone number gets
        $sellerSecondaryPhoneNumDataGet = mysqli_query($con, "SELECT contact_ph_num FROM tbl_address_master WHERE user_id = '" . $seller_id . "'");
        $sellerSecondaryPhoneNumData = mysqli_fetch_row($sellerSecondaryPhoneNumDataGet);
        $sellerSecondaryPhoneNum = $sellerSecondaryPhoneNumData[0];

        ## buyer phone number gets
        $buyerPhoneNumDataGet = mysqli_query($con, "SELECT ph_num, name FROM tbl_user_master WHERE user_id = '" . $buyer_id . "'");
        $buyerPhoneNumData = mysqli_fetch_row($buyerPhoneNumDataGet);
        $buyerPhoneNum = $buyerPhoneNumData[0];
        $buyerName = $buyerPhoneNumData[1];

        ## collector phone number gets if not blank
        if ($assigned_collecter) {
            $collectorPhoneNumDataGet = mysqli_query($con, "SELECT ph_num, name FROM tbl_user_master WHERE user_id = '" . $assigned_collecter . "'");
            $collectorPhoneNumData = mysqli_fetch_row($collectorPhoneNumDataGet);
            $collectorPhoneNum = $collectorPhoneNumData[0];
            $collectorName = $collectorPhoneNumData[1];
        }

        ## Sending SMS to buyer
        if ($buyerPhoneNum) {
            // Buyer message
            $sendPhNum = $buyerPhoneNum;
            $sendMssg = "Please contact " . $sellerPrimaryPhoneNum . " / " . $sellerSecondaryPhoneNum . " to pickup the scrap items - ZAG Tech Solutions";
            sendSms();

            ## Send whatsapp notification to the buyer
            $sendPhNum = $buyerPhoneNum;
            $sendTextMessage = "Dear '" . $buyerName . "', Your offer is accpeted by the '" . $sellerName . "', kindly get the scrap collected on  Date & Time.";
            sendWhatsappMessage();
        }

        ## Sending SMS to assigned collector if phone number is available
        if ($collectorPhoneNum) {
            // Collector message
            $sendPhNum = $collectorPhoneNum;
            $sendMssg = "Please contact " . $sellerPrimaryPhoneNum . " / " . $sellerSecondaryPhoneNum . " to pickup the scrap items - ZAG Tech Solutions";
            sendSms();

            // ## Send whatsapp notification to the buyer
            // $sendPhNum = $collectorPhoneNum;
            // $sendTextMessage = "Dear '" . $collectorName . "', Your offer is accpeted by the '" . $sellerName . "', kindly get the scrap collected on  Date & Time.";
            // sendWhatsappMessage();
        }

        $status = "success";
        $status_text = "Pickup Scheduled Successfully";
    }
}

$response[] = [
    'status' => $status,
    'status_text' => $status_text,
];
echo json_encode($response, true);
